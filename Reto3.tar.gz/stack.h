/**
* @author Alberto Estepa Fernández
* @file stack.h
* @brief Fichero cabecera del TDA stack
*
* Gestiona una secuencia de elementos con acceso inmediato al ultimo elemento introducido
*/

#ifndef PILA_H_
#define PILA_H_

#include <list>

using namespace std;

template <class T>
class Pila{
    list<T> l;

  public:

    /**
    * @brief Constructor por defecto
    * @post La pila queda inicializada a 0
    */
    Pila();

    /**
    * @brief Destructor
    * @post La pila queda vacía
    */
    ~Pila();

    /**
    * @brief Constructor de copias
    * @param p es una pila por referencia y constante para que no se genere una copia.
    * @post La pila posee los valores de la pila pasada por parámetro
    */
    Pila(const Pila<T>& p);

    /**
  	* @brief Sobrecarga del operador =
  	* @param p es una pila por referencia y constante para que no se genere una copia.
  	* @return La pila, que posee los valores de la pila pasada por parámetro
  	*/
    Pila& operator= (const Pila<T>& p);

    /**
    * @brief Pregunta si la pila está vacía
    * @return Si la pila está vacía, true.
    */
    bool vacia() const;

    /**
    * @brief Añade un elemento al tope de la pila
    * @param c elemento a meter en la pila
    * @post La pila se queda con un elemento más
    */
    void poner (T c);

    /**
    * @brief Elimina el último elemento introducido en la pila (tope).
    * @post La pila se queda con un elemento menos
    */
    void quitar();

    /**
  	* @brief Devuelve el último elemento introducido en la pila
  	* @return Tope de la pila
  	*/
    T tope() const;

    /**
  	* @brief Borra la lista
  	* @post La lista queda vacía
  	*/
    void clear();

    /**
  	* @brief Devuelve el último elemento introducido en la pila
  	* @return Número de elementos de la pila
  	*/
    unsigned int size();
};

#endif

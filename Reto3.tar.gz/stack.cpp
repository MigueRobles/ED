#include "stack.h"
#include <cassert>

template <class T>
  Pila<T>::Pila(){}

template <class T>
  Pila<T>::~Pila(){}

template <class T>
  Pila<T>::Pila(const Pila<T>& p){
    l = p.l;
  }

template <class T>
  Pila<T>& Pila<T>::operator= (const Pila<T>& p){
    if (this != p)
      l = p.l;
    return *this;
  }

template <class T>
  bool Pila<T>::vacia() const{
    return l.empty();
  }

template <class T>
  void Pila<T>::poner (T c){
    l.push_back(c);
  }

template <class T>
  void Pila<T>::quitar(){
    assert(!l.vacia());
      l.pop_back();
    }

template <class T>
  T Pila<T>::tope() const{
    assert(!l.vacia());
      return l.end();
  }

template <class T>
  void Pila<T>::clear(){
    l.clear();
  }

template <class T>
  unsigned int Pila<T>::size(){
    return l.size();
  }
